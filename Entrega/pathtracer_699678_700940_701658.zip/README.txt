Compilación:

g++ -std=c++11 *.cpp -O2 -o main

Ejecución:

./main spp width height fileName

