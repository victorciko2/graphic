Compilación:

sh buildpm.sh

Ejecución:

./smallpm -film-name filmname -film-size-x width -film-size-y height -pm-total-photons total_photons -scene scene -pm-photons-global global_photons -pm-photons-caustic caustic_photons -pm-photons-media medium_photons -pm-max-photons-shot max_photons -pm-nb-nearest-neighbor nearest_neighbor
